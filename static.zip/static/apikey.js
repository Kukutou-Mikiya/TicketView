export const GapiKey = 'AIzaSyB0kiyzsTHfKLz7Ige_QsG9ZoidKkMMQf4';
export const apiKey = '94UcyU0cGrWAaWAD6zABpFsfJKNi6znX';